# XPLAY Description to Playable Lab V2

This is a clean isolated test lane for:

**Editable Description → Interpreter V2 → Canonical Scene Graph → Gameplay Blueprint → Executable Asset Work Orders → QA Gate → Graybox Playable**

## What V2 fixes

- Preserves explicit source genre confidence like `fighting 95%`, `platformer 60%`, `dodge 45%`.
- Prevents the player's action field from swallowing the environment description.
- Normalizes duplicate landmark names into canonical scene entities.
- Parses 3 fighting enemies for the Alex dockyard sample when source text supports them.
- Adds source/inference provenance to positions and facts.
- Converts the Asset Manifest into executable work orders:
  - REBUILD
  - EXTRACT_OR_REBUILD
  - EXTEND_OR_REBUILD
  - SYNTHESIZE
- Adds production routes, deliverables, and QA gates per asset.
- Adds an Interpreter QA/readiness score.
- Blocks the graybox below 70% readiness.
- Does not use old Reverse Forge assets.

## Install

Copy:

`XPLAYEngine/public/labs/description-to-playable-v2/`

into the same location inside your XPLAYEngine repository.

Then run XPLAY and open:

Local:
`http://localhost:5173/labs/description-to-playable-v2/index.html`

Live after GitHub Pages deploy:
`https://2flykl.github.io/XPLAYEngine/labs/description-to-playable-v2/index.html`

## Testing

1. Start with the included Alex text.
2. Run **Interpreter V2**.
3. Check QA/readiness.
4. Build the graybox.
5. Change the source text to a completely different game prompt.
6. Re-run.
7. Download the V2 packet JSON when useful.

This V2 intentionally remains independent from the old creator pipeline until its outputs are consistently correct across multiple prompts.


## V2.1 pacing / scrolling experiment

This test revision adds:
- ~50% slower player movement.
- much slower enemy pursuit.
- 2200px horizontal world instead of a single 960px screen.
- camera follows the player horizontally.
- extended dockyard graybox dressing beyond the starting screen.
- target encounter duration of roughly 15 seconds.
- passive player health depletion of about 1% of the initial health bar per second.
- enemy HP increased slightly.
- reinforcements appear if the first wave is cleared too early.
- stage can only clear after the 15-second test window.
- third-rival consistency patch for the Alex sample.


# V2.2 Stress Harness

V2.2 is intended to stress the runtime thresholds before asset production is connected.

Added:
- Camera dead-zone scrolling.
- 2600px horizontal fighting test world.
- 15-second minimum target combat window.
- Slower controllable player speed.
- Enemy archetypes: fast knife, balanced rival, slow bruiser.
- Enemy attack cooldowns and player invulnerability frames.
- Passive slow health depletion.
- Mid-stage health pickup.
- Timed reinforcement wave.
- Scroll-triggered second encounter zone.
- Late bruiser wave.
- Lightweight adaptive difficulty governor.
- Telemetry:
  - elapsed time
  - enemies defeated
  - damage taken
  - max camera scroll
  - waves reached
  - attacks and hits
- End-of-run threshold warnings.
- Three alternate vision-style prompts built into the UI and included as TXT files:
  - Platformer
  - Runner
  - Dodge

The current graybox engine is still Fighting-focused. The alternate prompts are primarily testing the Interpreter/Scene Graph/Blueprint architecture and genre separation. Use their parsed output to see whether fighting assumptions leak into other genres.


# V2.3 Multi-Runtime Fix

V2.2 correctly parsed Platformer, Runner, and Dodge descriptions, but the graybox builder still always launched the Fighting runtime.

V2.3 fixes that architecture problem.

The builder now dispatches from:
`gameplayBlueprint.engine`

Implemented graybox runtimes:
- Fighting / Beat 'em Up
- Platformer
- Runner
- Dodge

This means a new parsed genre now changes the playable mechanics, camera, world structure, objective and controls instead of merely changing JSON.

Use the included Platformer / Runner / Dodge buttons again and compare both:
1. parsed packet
2. actual graybox runtime
