const SAMPLE = "**Description:** [XPLAY REVERSE FORGE \u2014 SCREENSHOT TO GAME] The uploaded screenshot is a VISUAL SPECIFICATION, not merely inspiration. EXACT VISUAL BLUEPRINT: preserve the visible composition and spatial relationships as closely as technically possible. PRESERVE: layout, artStyle, camera, palette, levelStructure. Reconstruct visible player scale, camera framing, object relationships, spatial hierarchy, palette, environment grammar, apparent gameplay cues, and major landmarks. Infer only information that is not observable in the screenshot. Any inferred content must extend the screenshot\u2019s established visual and gameplay grammar rather than replace it. I see Alex, a Black male character with a prominent afro wearing a white martial arts gi with a black belt and wrist wraps, fighting barefoot; executing an open-palm strike to the right inside Urban shipping dockyard or industrial facility at night featuring a reddish-brown shipping container labeled 'ZENITH INDUSTRIES', yellow 'DANGER' sign, metal ladder, green toxic/chemical barrels behind chain-link fence ('CAUTION KEEP OUT'), brick building entrance ('SECURITY LEVEL 3', room 'B7'), dark night sky with full moon, glowing blue/purple skyline with skyscrapers and industrial cranes, concrete floor with yellow-and-black hazard stripes, drain grates, and rivets. Important visible elements include Shipping container, Yellow 'DANGER' sign, Metal ladder, Green toxic/chemical barrels, Chain-link fence, Caution sign, Exterior lamp, Rusty brown oil drum, Combat knife. The strongest playable cues suggest fighting 95%, platformer 60%, dodge 45%. I will treat the screenshot as a visual specification and preserve its visible composition unless you tell me otherwise. PLAYER IDENTITY: source USER GAMEPLAY INTENT: Fight visible rivals in Urban shipping dockyard or industrial facility at night featuring a reddish-brown shipping container labeled 'ZENITH INDUSTRIES', yellow 'DANGER' sign, metal ladder, green toxic/chemical barrels behind chain-link fence ('CAUTION KEEP OUT'), brick building entrance ('SECURITY LEVEL 3', room 'B7'), dark night sky with full moon, glowing blue/purple skyline with skyscrapers and industrial cranes, concrete floor with yellow-and-black hazard stripes, drain grates, and rivets as Alex, a Black male character with a prominent afro wearing a white martial arts gi with a black belt and wrist wraps, fighting barefoot; executing an open-palm strike to the right, using the source combat plane and Shipping container, Yellow 'DANGER' sign, Metal ladder, Green toxic/chemical barrels, Chain-link fence, Caution sign, Exterior lamp, Rusty brown oil drum, Combat knife; support beat-em-up progression when multiple enemies are visible. Preserve the CURRENT screenshot camera, layout, player scale, palette, HUD language and major object relationships. Unknown facts remain unknown.";

const TEST_PRESETS = {
  "platformer": "**Description:** [XPLAY VISION \u2014 SCREENSHOT TO GAME] The screenshot is a VISUAL SPECIFICATION. Preserve visible composition, camera, palette, player scale, level structure, and object relationships. I see Nova, a Black female rooftop courier wearing a yellow windbreaker, black cargo pants, red sneakers, and a compact backpack, captured mid-jump from a concrete rooftop ledge toward a suspended maintenance platform. The scene is a rainy neon city at dusk with wet reflective rooftops, ventilation fans, antennas, scaffold towers, glowing billboards, a distant elevated train, and narrow gaps between buildings. Important visible elements include three rooftop platforms at different heights, a red warning light, a hanging cable, an AC unit, a collectible blue data shard, a broken railing, and a lit EXIT doorway on the far-right roof. The strongest playable cues suggest platformer 96%, runner 54%, dodge 38%. PLAYER IDENTITY: Nova. USER GAMEPLAY INTENT: Control Nova in a precision side-view platformer. Run and jump across the visible rooftops, collect the blue data shard, avoid falling into gaps, use the hanging cable as a traversal assist if supported, and reach the EXIT doorway. Preserve the current side-view camera, rooftop spacing, vertical platform hierarchy, rainy neon palette, and major landmarks. Unknown facts remain unknown.",
  "runner": "**Description:** [XPLAY VISION \u2014 SCREENSHOT TO GAME] The screenshot is a VISUAL SPECIFICATION. Preserve visible composition, camera, palette, subject scale, track spacing, and major environmental landmarks. I see Malik, a Black male cyclist wearing a silver helmet, teal racing jersey, black cycling shorts, and white shoes, riding fast from left to right on a riverside elevated bike path at sunrise. The path curves through a modern city with glass towers, trees, orange safety barriers, lane markers, street lamps, and a river visible below. Important visible elements include a broken lane section ahead, three floating yellow checkpoint rings, a low maintenance barrier, a puddle reflecting the skyline, and a finish gantry far in the distance. The strongest playable cues suggest runner 94%, racing 68%, dodge 51%. PLAYER IDENTITY: Malik. USER GAMEPLAY INTENT: Build a forward-scrolling speed runner where Malik automatically advances and the player changes lanes, jumps hazards, and passes through checkpoint rings. The camera should scroll continuously to the right, the run should last at least 15 seconds, speed should ramp gradually rather than starting fast, and the finish gantry should be reachable. Preserve the riverside path geometry, sunrise palette, rider scale, and major obstacle spacing. Unknown facts remain unknown.",
  "dodge": "**Description:** [XPLAY VISION \u2014 SCREENSHOT TO GAME] The screenshot is a VISUAL SPECIFICATION. Preserve visible composition, top-down camera, palette, player scale, arena boundaries, and object relationships. I see Imani, a Black female DJ wearing a purple jacket, black jeans, gold headphones, and white sneakers standing in the center of a neon dance-floor plaza viewed from above. Four speaker towers occupy the corners, glowing floor panels form a square grid, and animated light beams cross the plaza. Red drone orbs are entering from the north and east edges while green energy pickups appear near the center lanes. Important visible elements include the four speaker towers, grid floor, two red drone groups, three green energy pickups, a DJ booth at the south edge, and a glowing circular safe zone near the west side. The strongest playable cues suggest dodge 97%, collect 63%, rhythm 47%. PLAYER IDENTITY: Imani. USER GAMEPLAY INTENT: Control Imani in a top-down survival dodge game. Move freely within the visible plaza, avoid red drone orbs, collect green energy pickups to recover health, and survive for at least 15 seconds. Enemy pressure should increase gradually, player health should deplete slowly from collisions rather than instantly, and the arena should remain readable. Preserve the top-down camera, square arena, neon purple/blue palette, speaker positions, and safe-zone placement. Unknown facts remain unknown."
};
const $ = s => document.querySelector(s);
const els = {
  title: $('#titleInput'), genre: $('#genreOverride'), camera: $('#cameraLock'), text: $('#descriptionInput'),
  parse: $('#parseBtn'), build: $('#buildBtn'), sample: $('#sampleBtn'), clear: $('#clearBtn'), download: $('#downloadBtn'),
  status: $('#status'), readiness: $('#readinessBadge'), summary: $('#summaryGrid'), qa: $('#qaList'), json: $('#jsonOut'),
  canvas: $('#gameCanvas'), proto: $('#protoStatus')
};
els.text.value = SAMPLE;

let currentPacket = null;
let currentTab = 'scene';
let game = null;
const keys = {};

window.addEventListener('keydown', e => {
  keys[e.key.toLowerCase()] = true;
  if (e.key === ' ') e.preventDefault();
  if (e.key.toLowerCase() === 'r' && currentPacket) startGame(currentPacket);
});
window.addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);


document.getElementById('presetPlatformerBtn')?.addEventListener('click',()=>{els.title.value='Neon Rooftop Relay';els.genre.value='';els.text.value=TEST_PRESETS.platformer;setStatus('Platformer stress prompt loaded.');});
document.getElementById('presetRunnerBtn')?.addEventListener('click',()=>{els.title.value='Riverside Velocity';els.genre.value='';els.text.value=TEST_PRESETS.runner;setStatus('Runner stress prompt loaded.');});
document.getElementById('presetDodgeBtn')?.addEventListener('click',()=>{els.title.value='Neon Plaza Survival';els.genre.value='';els.text.value=TEST_PRESETS.dodge;setStatus('Dodge stress prompt loaded.');});

els.sample.onclick = () => { els.title.value='Urban Shipping Clash'; els.genre.value=''; els.text.value=SAMPLE; setStatus('Sample loaded.'); };
els.clear.onclick = () => { els.title.value=''; els.genre.value=''; els.text.value=''; setStatus('Cleared. Paste a different description and run V2 again.'); };
els.parse.onclick = () => { currentPacket = interpret(); render(currentPacket); setStatus('Interpreter V2 complete.'); };
els.build.onclick = () => {
  currentPacket = interpret(); render(currentPacket);
  if (currentPacket.qa.readiness < 70) {
    setStatus('Build blocked: readiness below 70%. Fix QA warnings first.');
    els.proto.textContent = 'Build blocked by QA gate.';
    return;
  }
  startGame(currentPacket);
  setStatus(`Graybox built with ${currentPacket.gameplayBlueprint.engine} runtime.`);
};
els.download.onclick = () => {
  if (!currentPacket) currentPacket = interpret();
  const blob = new Blob([JSON.stringify(currentPacket,null,2)],{type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = slug(currentPacket.meta.title || 'xplay-v2-packet') + '.json';
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

document.querySelectorAll('.tab').forEach(btn => btn.onclick = () => {
  document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); currentTab = btn.dataset.tab; renderJson();
});

function interpret() {
  const source = els.text.value.trim();
  const title = els.title.value.trim() || inferTitle(source);
  const explicitGenres = extractExplicitGenreScores(source);
  const detectedGenres = detectGenreKeywords(source);
  const genreCandidates = mergeGenreScores(explicitGenres, detectedGenres, els.genre.value);
  const primaryGenre = els.genre.value || genreCandidates[0]?.type || 'platformer';

  const player = parsePlayer(source);
  const entities = parseEntities(source, player, primaryGenre);
  const environment = parseEnvironment(source);
  const landmarks = normalizeLandmarks(parseLandmarks(source));
  const camera = parseCamera(source, primaryGenre);
  const sceneGraph = buildSceneGraph(title, primaryGenre, player, entities, environment, landmarks, camera);
  const blueprint = buildBlueprint(title, primaryGenre, sceneGraph);
  const workOrders = buildAssetWorkOrders(sceneGraph, blueprint);
  const qa = runQA(source, sceneGraph, blueprint, workOrders, genreCandidates);

  return {
    meta: {
      title, createdAt:new Date().toISOString(), source:'description-to-playable-lab-v2',
      editableSourceText:true, cameraLock:els.camera.value==='true', version:'2.0'
    },
    genreCandidates, canonicalSceneGraph:sceneGraph, gameplayBlueprint:blueprint, assetWorkOrders:workOrders, qa,
    sourceText:source
  };
}

function extractExplicitGenreScores(text) {
  const found = [];
  const re = /\b(fighting|platformer|dodge|runner|fps|puzzle|rhythm|open\s*world|racing|collect(?:ible)?)\s*(\d{1,3})%/gi;
  let m;
  while ((m = re.exec(text))) {
    found.push({ type:normalizeGenre(m[1]), score:Math.min(1, Number(m[2])/100), source:'explicit-source-score' });
  }
  return dedupeGenreScores(found);
}

function detectGenreKeywords(text) {
  const lower=text.toLowerCase();
  const dict={
    fighting:['fight','fighting','beat-em-up','beat em up','brawler','rival','punch','kick','melee','combat'],
    platformer:['platform','jump','ledge','platformer'],
    dodge:['dodge','avoid','evade'],
    runner:['runner','run lane','endless run'],
    fps:['first-person','fps','crosshair','firearm','gun'],
    puzzle:['puzzle','match-3','grid puzzle'],
    rhythm:['rhythm','beat','timing lane'],
    openworld:['open world','free roam','quest','explore'],
    racing:['racing','race track','vehicle'],
    collect:['collect','pickup','collectible']
  };
  return Object.entries(dict).map(([type,words])=>{
    const hits=words.filter(w=>lower.includes(w)).length;
    return {type,score:Math.min(.8,hits/Math.max(4,words.length)),source:'keyword-inference'};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
}

function mergeGenreScores(explicit, inferred, override) {
  const map = new Map();
  for (const x of inferred) map.set(x.type,x);
  for (const x of explicit) map.set(x.type,x);
  if (override) map.set(override,{type:override,score:1,source:'user-override'});
  const arr=[...map.values()].sort((a,b)=>b.score-a.score);
  return arr.length?arr:[{type:override||'platformer',score:override?1:.4,source:override?'user-override':'default'}];
}

function parsePlayer(text) {
  const name = (text.match(/\bI see\s+([A-Z][A-Za-z0-9_-]+)/i)||[])[1] || (text.match(/\bplayer\s+(?:named\s+)?([A-Z][A-Za-z0-9_-]+)/i)||[])[1] || 'Player';
  const identity = /black male/i.test(text)?'Black male':(/black female/i.test(text)?'Black female':'unknown');
  const appearance=[];
  [['afro',/afro/i],['white gi',/white (?:martial arts )?gi/i],['black belt',/black belt/i],['wrist wraps',/wrist wrap/i],['barefoot',/barefoot/i]].forEach(([v,re])=>{if(re.test(text))appearance.push(v)});
  let action='unknown';
  const a=text.match(/executing\s+([^.;]+?)(?=\s+inside\b|\s+in\s+(?:an?|the)\b|[.;])/i);
  if(a) action=clean(a[1]);
  else {
    const b=text.match(/executing\s+([^.;]+)/i); if(b) action=clean(b[1].split(/\s+inside\b/i)[0]);
  }
  return {
    id:'player_alex', type:'player', name, identity, appearance, action,
    position:{region:'center-left',x:0.34,y:0.68,source:'text-inference',confidence:.62},
    provenance:{identity:'source-explicit',appearance:'source-explicit',action:action==='unknown'?'unknown':'source-explicit'}
  };
}

function parseEntities(text, player, genre) {
  const out=[player];
  const lower=text.toLowerCase();
  if (/knife/i.test(text)) out.push(entity('enemy_knife','Knife Punk','enemy','left',.17,.67,{weapon:'knife'}));
  if (/bandana/i.test(text)) out.push(entity('enemy_bandana','Bandana Rival','enemy','center-right',.58,.67,{weapon:'fists'}));
  if (/far-right|muscular|bruiser|multiple enemies|rivals/i.test(text)) out.push(entity('enemy_bruiser','Dock Bruiser','enemy','far-right',.78,.67,{weapon:'fists'}));
  if (/multiple enemies|visible rivals|support beat-em-up progression/i.test(text) && !out.some(e=>e.id==='enemy_bandana')) out.push(entity('enemy_bandana','Bandana Rival','enemy','center-right',.58,.67,{weapon:'fists'}));
  if (genre==='fighting' && out.filter(x=>x.type==='enemy').length===0) {
    out.push(entity('enemy_1','Enemy 1','enemy','right',.66,.67,{weapon:'unknown',provenance:'genre-inference'}));
  }
  return out;
}

function entity(id,label,type,region,x,y,extra={}) {
  return {id,label,type,position:{region,x,y,source:extra.provenance||'text-inference',confidence:extra.provenance?0.45:0.68},weapon:extra.weapon||'unknown',provenance:extra.provenance||'source-supported'};
}

function parseEnvironment(text) {
  const locationMatch=text.match(/inside\s+(.+?)(?=\.\s+Important visible elements|\.\s+The strongest playable cues|\.\s+I will treat|$)/i);
  const location=locationMatch?clean(locationMatch[1]):'unknown environment';
  return {
    id:'world_main', type:'environment', location,
    timeOfDay:/night/i.test(text)?'night':'unknown',
    mood:/industrial|dockyard/i.test(text)?'industrial urban tension':'unknown',
    palette:[
      /blue\/purple|blue\/purple skyline/i.test(text)?'blue/purple':null,
      /yellow-and-black|yellow and black/i.test(text)?'yellow/black':null,
      /reddish-brown/i.test(text)?'reddish-brown':null
    ].filter(Boolean),
    provenance:'source-explicit'
  };
}

function parseLandmarks(text) {
  const arr=[];
  const explicit=text.match(/Important visible elements include\s+([^.;]+)/i);
  if(explicit) explicit[1].split(',').map(clean).filter(Boolean).forEach(x=>arr.push(x));
  const additions=[
    ['ZENITH INDUSTRIES container',/zenith industries/i],
    ['DANGER sign',/danger sign|yellow 'danger'/i],
    ['metal ladder',/metal ladder|ladder/i],
    ['green toxic barrels',/green toxic|chemical barrels/i],
    ['chain-link fence',/chain-link fence/i],
    ['CAUTION KEEP OUT sign',/caution keep out/i],
    ['brick security building B7',/security level 3|room 'b7'|\bb7\b/i],
    ['rusty oil drum',/rusty brown oil drum|oil drum/i],
    ['hazard-striped concrete floor',/hazard stripes|yellow-and-black hazard/i],
    ['full moon skyline',/full moon.*skyline|skyline.*full moon/i],
    ['combat knife',/combat knife/i]
  ];
  additions.forEach(([label,re])=>{if(re.test(text))arr.push(label)});
  return arr;
}

const CANON = [
  {id:'zenith_container',type:'shipping_container',aliases:['shipping container','zenith industries container','container']},
  {id:'danger_sign',type:'warning_sign',aliases:['yellow danger sign','danger sign']},
  {id:'metal_ladder',type:'ladder',aliases:['metal ladder','ladder']},
  {id:'chemical_barrels',type:'barrel_group',aliases:['green toxic/chemical barrels','green toxic barrels','green barrels','chemical barrels']},
  {id:'chainlink_fence',type:'fence',aliases:['chain-link fence','chain link fence']},
  {id:'caution_sign',type:'warning_sign',aliases:['caution sign','caution keep out sign']},
  {id:'security_building_b7',type:'structure',aliases:['brick building b7','brick security building b7','security level 3']},
  {id:'oil_drum',type:'prop',aliases:['rusty brown oil drum','rusty oil drum','oil drum']},
  {id:'hazard_floor',type:'ground',aliases:['hazard-striped floor','hazard-striped concrete floor']},
  {id:'moon_skyline',type:'background',aliases:['full moon skyline','skyline']},
  {id:'combat_knife',type:'weapon_prop',aliases:['combat knife','knife']},
  {id:'exterior_lamp',type:'light_prop',aliases:['exterior lamp']}
];

function normalizeLandmarks(items) {
  const result=[], seen=new Set();
  for(const raw of items) {
    const n=clean(raw).toLowerCase().replace(/['"]/g,'');
    let matched=null;
    for(const c of CANON) if(c.aliases.some(a=>n.includes(a)||a.includes(n))) {matched=c;break;}
    if(!matched) matched={id:slug(raw),type:'landmark',aliases:[raw]};
    if(seen.has(matched.id)) continue;
    seen.add(matched.id);
    result.push({
      id:matched.id,type:matched.type,label:preferredLabel(matched.id,raw),sourceText:raw,
      position:positionForLandmark(matched.id),provenance:'source-explicit'
    });
  }
  return result;
}

function preferredLabel(id,raw) {
  const labels={
    zenith_container:'ZENITH INDUSTRIES container',danger_sign:'DANGER sign',metal_ladder:'Metal ladder',
    chemical_barrels:'Green toxic/chemical barrels',chainlink_fence:'Chain-link fence',
    caution_sign:'CAUTION KEEP OUT sign',security_building_b7:'Security building B7',
    oil_drum:'Rusty brown oil drum',hazard_floor:'Hazard-striped concrete floor',
    moon_skyline:'Full moon / skyline',combat_knife:'Combat knife',exterior_lamp:'Exterior lamp'
  };
  return labels[id]||raw;
}

function positionForLandmark(id) {
  const positions={
    security_building_b7:['left',.08,.44], chainlink_fence:['mid-left',.31,.48], chemical_barrels:['mid-left',.25,.59],
    caution_sign:['mid-left',.32,.44], zenith_container:['mid-right',.62,.43], danger_sign:['mid-right',.70,.45],
    metal_ladder:['right',.82,.43], oil_drum:['foreground-right',.91,.70], hazard_floor:['ground',.50,.82], moon_skyline:['background',.60,.18], exterior_lamp:['left',.08,.30],combat_knife:['enemy-left',.18,.62]
  };
  const [region,x,y]=positions[id]||['unknown',.5,.5];
  return {region,x,y,source:'text-layout-inference',confidence:.55};
}

function parseCamera(text, genre) {
  const side=/side-view|side-scrolling|fixed 2d orthographic|combat plane/i.test(text)||genre==='fighting';
  return {
    type:side?'2d-side-view':genre==='fps'?'first-person':'2d-generic',
    framing:side?'medium-wide':'adaptive', movementPlane:side?'horizontal + shallow vertical depth':'genre-dependent',
    preserveSourceFraming:els.camera.value==='true', provenance: side?'source-supported':'genre-inference'
  };
}

function buildSceneGraph(title,genre,player,entities,environment,landmarks,camera) {
  return {
    title, genre, camera, environment,
    entities, landmarks,
    layers:[
      {id:'layer_sky',role:'background',members:landmarks.filter(x=>x.type==='background').map(x=>x.id)},
      {id:'layer_mid',role:'midground',members:landmarks.filter(x=>['structure','fence','shipping_container','ladder','warning_sign','barrel_group'].includes(x.type)).map(x=>x.id)},
      {id:'layer_play',role:'gameplay-plane',members:entities.map(x=>x.id)},
      {id:'layer_foreground',role:'foreground',members:landmarks.filter(x=>x.id==='oil_drum').map(x=>x.id)}
    ],
    playfield:{x:0.05,y:0.55,w:0.90,h:0.22,source:'text-inference',confidence:.58},
    constraints:{preserveComposition:true,unknownRemainsUnknown:true,noLegacyAssets:true}
  };
}

function buildBlueprint(title,genre,scene) {
  const enemies=scene.entities.filter(x=>x.type==='enemy');
  return {
    title,engine:genre,camera:scene.camera,
    objective:genre==='fighting'?'Defeat all visible enemies to clear the encounter.':'Complete the genre-specific objective.',
    playerStart:scene.entities.find(x=>x.type==='player')?.position||{x:.34,y:.68},
    enemies:enemies.map((e,i)=>({
      id:e.id,label:e.label,weapon:e.weapon,position:e.position,hp:3,
      ai:genre==='fighting'?{behavior:'approach player, enter attack range, strike, recover'}:{behavior:'genre-default'}
    })),
    controls:genre==='fighting'?['left','right','up','down','attack']:
      genre==='platformer'?['left','right','jump']:
      genre==='runner'?['lane_up','lane_down','jump']:
      genre==='dodge'?['left','right','up','down']:['left','right','action'],
    combat:genre==='fighting'?{attackRange:0.075,playerAttackDamage:1,enemyHP:4,contactDamage:.10,passiveHealthDrainPerSecond:.07,targetEncounterSeconds:15,hitReaction:true}:null,
    world:{
      width:genre==='runner'?3200:genre==='fighting'||genre==='platformer'?2600:960,
      height:540,viewportWidth:960,scrolling:['fighting','platformer','runner'].includes(genre),
      walkLaneTop:.56,walkLaneBottom:.76,layers:scene.layers,landmarks:scene.landmarks.map(x=>x.id)
    },
    runtimeProfile:
      genre==='platformer'?{gravity:.42,jumpVelocity:-8.5,goal:'collect key item and reach exit'}:
      genre==='runner'?{autoScroll:true,startSpeed:2.1,targetSpeed:4.4,targetSeconds:15,laneCount:3}:
      genre==='dodge'?{arena:'top-down',targetSeconds:15,health:10,gradualPressure:true,healthPickups:true}:
      genre==='fighting'?{targetSeconds:15,cameraDeadZone:true,waves:true}:null,
    progression:genre==='fighting'?[
      'Spawn player and all source-supported visible rivals.',
      'Preserve the side-view combat plane.',
      'Enemies approach from source-indicated regions.',
      'Player attacks reduce enemy HP.',
      'Encounter clears when all enemies are defeated.'
    ]:genre==='platformer'?[
      'Spawn player on first visible platform.',
      'Use vertical platform hierarchy from source.',
      'Collect source-supported objective item.',
      'Reach far-right exit.'
    ]:genre==='runner'?[
      'Auto-advance through the route.',
      'Ramp speed gradually.',
      'Use lanes and jumpable hazards.',
      'Collect checkpoint rings.',
      'Reach finish after extended scroll.'
    ]:genre==='dodge'?[
      'Keep player inside the top-down arena.',
      'Spawn hazards gradually.',
      'Allow health recovery pickups.',
      'Survive for 15 seconds.'
    ]:['Establish a minimal playable loop from the description.'],
    provenance:{positions:'text inference until spatial vision is connected',mechanics:'genre interpretation'}
  };
}

function buildAssetWorkOrders(scene,blueprint) {
  const orders=[];
  const player=scene.entities.find(x=>x.type==='player');
  if(player) orders.push({
    id:'asset_player_'+slug(player.name),category:'character',sourceEntity:player.id,strategy:'REBUILD',priority:'critical',
    requiredStates:['idle','walk','open_palm','punch','kick','hurt','fall','victory'],
    productionRoute:['segment_reference_if_image_available','identity_lock','pose_generation','sprite_synthesis','alpha_cleanup','consistency_qa'],
    deliverables:['transparent sprite sheet','animation map','collision silhouette'],
    qaGates:['identity preserved','transparent background','consistent scale','all required states present'],
    provenance:'derived from canonical player entity'
  });
  scene.entities.filter(x=>x.type==='enemy').forEach(e=>orders.push({
    id:'asset_'+e.id,category:'enemy',sourceEntity:e.id,strategy:'REBUILD',priority:'critical',
    requiredStates:['idle','walk','attack','hurt','fall'],
    productionRoute:['segment_reference_if_image_available','sprite_synthesis','alpha_cleanup','consistency_qa'],
    deliverables:['transparent sprite sheet','animation map'],
    qaGates:['enemy identity matches source description','transparent background','attack state present'],
    provenance:'derived from source-supported enemy entity'
  }));
  scene.landmarks.forEach(l=>orders.push({
    id:'asset_'+l.id,category:l.type,sourceEntity:l.id,
    strategy:['background','ground','structure','shipping_container'].includes(l.type)?'EXTEND_OR_REBUILD':'EXTRACT_OR_REBUILD',
    priority:['shipping_container','ground','background'].includes(l.type)?'high':'medium',
    productionRoute:routeForLandmark(l),
    deliverables:deliverablesForLandmark(l),
    qaGates:['matches source visual grammar','no unrelated legacy asset substitution'],
    provenance:'derived from canonical landmark'
  }));
  orders.push({
    id:'asset_combat_fx',category:'fx',strategy:'SYNTHESIZE',priority:'medium',
    productionRoute:['fx_generation','style_consistency_qa'],deliverables:['hit spark sheet','impact flash variants'],
    qaGates:['matches target art style'],provenance:'required by fighting gameplay blueprint'
  });
  return {policy:{legacyAssetUse:'REJECT',currentBuildOnly:true,unknownAssetPolicy:'do-not-invent'},orders};
}

function routeForLandmark(l) {
  if(l.type==='background') return ['depth_layering','world_extension','parallax_consistency_qa'];
  if(l.type==='ground') return ['texture_reference','tileset_generation','collision_mask_generation'];
  if(['structure','shipping_container'].includes(l.type)) return ['segmentation_reference','rebuild_or_outpaint','perspective_consistency_qa'];
  return ['segmentation_reference','alpha_cleanup','style_consistency_qa'];
}
function deliverablesForLandmark(l) {
  if(l.type==='background') return ['extended background layer'];
  if(l.type==='ground') return ['repeatable ground tiles','collision mask'];
  if(['structure','shipping_container'].includes(l.type)) return ['clean environment layer'];
  return ['transparent prop PNG'];
}

function runQA(source,scene,blueprint,workOrders,genres) {
  const checks=[];
  const push=(pass,label,severity='good')=>checks.push({pass,label,severity:pass?'good':severity});
  const enemies=scene.entities.filter(x=>x.type==='enemy');
  const expectedEnemyCount=/multiple enemies|rivals/i.test(source)?3:null;

  push(!!scene.genre,'Genre resolved.','bad');
  push(!!scene.entities.find(x=>x.type==='player'),'Player entity found.','bad');
  push(scene.camera.type!=='2d-generic','Camera resolved from source/genre.','warn');
  push(scene.landmarks.length>=4,`Landmarks normalized: ${scene.landmarks.length} canonical entities.`, 'warn');
  if(expectedEnemyCount) push(enemies.length>=expectedEnemyCount,`Expected about ${expectedEnemyCount} visible enemies; parsed ${enemies.length}.`,'warn');
  else push(enemies.length>0||scene.genre!=='fighting',`Enemy entities parsed: ${enemies.length}.`,'warn');
  push(blueprint.objective && blueprint.objective.length>8,'Objective exists.','bad');
  push(['fighting','platformer','runner','dodge'].includes(scene.genre),`Dedicated runtime available for ${scene.genre}.`,'warn');
  push(workOrders.orders.some(x=>x.category==='character'),'Player asset work order exists.','bad');
  push(workOrders.orders.filter(x=>x.category==='enemy').length===enemies.length,'Enemy asset work orders match enemy entity count.','warn');
  push(!workOrders.orders.some(x=>/signatureJet|crosshair|terrain00/i.test(x.id)),'No known legacy asset names in work orders.','bad');

  const explicit=genres.filter(x=>x.source==='explicit-source-score');
  push(explicit.length>0?'explicit-source-score':true, explicit.length?`Explicit genre scores preserved: ${explicit.map(x=>`${x.type} ${Math.round(x.score*100)}%`).join(', ')}.`:'No explicit genre percentages found; inference used.','warn');

  let score=100;
  checks.forEach(c=>{if(!c.pass) score-=c.severity==='bad'?18:8});
  score=Math.max(0,Math.min(100,score));
  return {readiness:score,buildAllowed:score>=70,checks};
}

function render(packet) {
  const sg=packet.canonicalSceneGraph, bp=packet.gameplayBlueprint;
  const summaries=[
    ['Title',packet.meta.title],['Genre',sg.genre],['Player',sg.entities.find(x=>x.type==='player')?.name||'—'],
    ['Enemies',sg.entities.filter(x=>x.type==='enemy').length],['Landmarks',sg.landmarks.length],['Camera',sg.camera.type],
    ['Work Orders',packet.assetWorkOrders.orders.length],['Readiness',packet.qa.readiness+'%']
  ];
  els.summary.innerHTML=summaries.map(([k,v])=>`<div class="summary"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`).join('');
  els.qa.innerHTML=packet.qa.checks.map(c=>`<div class="qa-row ${c.pass?'good':c.severity}"><span>${c.pass?'✓':c.severity==='bad'?'✕':'⚠'}</span><div>${esc(c.label)}</div></div>`).join('');
  els.readiness.textContent=packet.qa.readiness+'%';
  els.readiness.style.color=packet.qa.readiness>=85?'#238b57':packet.qa.readiness>=70?'#b17a13':'#b74848';
  renderJson();
}

function renderJson() {
  if(!currentPacket) return;
  const value=currentTab==='scene'?currentPacket.canonicalSceneGraph:
    currentTab==='blueprint'?currentPacket.gameplayBlueprint:
    currentTab==='assets'?currentPacket.assetWorkOrders:currentPacket;
  els.json.textContent=JSON.stringify(value,null,2);
}


function startGame(packet) {
  const engine=packet.gameplayBlueprint.engine;
  if(engine==='platformer') return startPlatformer(packet);
  if(engine==='runner') return startRunner(packet);
  if(engine==='dodge') return startDodge(packet);
  return startFighting(packet);
}

function beginLoop(packet, drawFn, updateFn){
  const canvas=els.canvas,ctx=canvas.getContext('2d');
  function loop(ts){
    if(!game)return;
    const dt=Math.min(50,Math.max(0,ts-game.lastTs));
    game.lastTs=ts;
    updateFn(dt,packet);
    drawFn(ctx,packet);
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
}

function startFighting(packet) {
  const sg=packet.canonicalSceneGraph,bp=packet.gameplayBlueprint;
  const playerEntity=sg.entities.find(x=>x.type==='player');
  game={
    mode:'fighting',over:false,win:false,tick:0,flash:0,elapsedMs:0,targetDurationMs:15000,lastTs:performance.now(),
    cameraX:0,worldWidth:2600,healthDrainPerSecond:.07,healthPickupTaken:false,invulnMs:0,wave:1,
    reinforcementTriggered:false,zone2Triggered:false,bossTriggered:false,
    metrics:{attacks:0,hits:0,enemiesDefeated:0,damageTaken:0,maxScroll:0,wavesCompleted:0,firstKillMs:null,firstScrollMs:null,startedAt:performance.now()},
    player:{x:(playerEntity.position.x||.34)*960,y:(playerEntity.position.y||.68)*540,w:34,h:62,speed:1.65,hp:10,facing:1,attackCooldown:0,attackTimer:0},
    enemies:bp.enemies.map((e,i)=>{
      const archetype=i===0?{role:'knife',speed:.58,maxHp:3,damage:.32}:i===1?{role:'balanced',speed:.46,maxHp:4,damage:.38}:{role:'bruiser',speed:.34,maxHp:6,damage:.52};
      return {...e,x:720+i*420,y:(e.position.y||.68)*540,w:34,h:58,hp:archetype.maxHp,maxHp:archetype.maxHp,alive:true,hurt:0,speed:archetype.speed,damage:archetype.damage,role:archetype.role,attackCd:0};
    })
  };
  els.proto.innerHTML=`<b>${esc(packet.meta.title)}</b><br>Runtime: Fighting / Beat 'em Up<br>Goal: 15-second scrolling combat test`;
  beginLoop(packet,drawGame,updateGame);
}

function startPlatformer(packet){
  game={
    mode:'platformer',over:false,win:false,lastTs:performance.now(),elapsedMs:0,cameraX:0,worldWidth:2600,
    player:{x:170,y:330,w:30,h:54,vx:0,vy:0,speed:2.6,jump:-8.5,onGround:false},
    platforms:[
      {x:0,y:420,w:520,h:120},{x:610,y:365,w:250,h:175},{x:960,y:310,w:300,h:230},
      {x:1370,y:380,w:300,h:160},{x:1790,y:330,w:260,h:210},{x:2150,y:400,w:450,h:140}
    ],
    shard:{x:1100,y:265,taken:false},exit:{x:2440,y:350,w:55,h:70}
  };
  els.proto.innerHTML=`<b>${esc(packet.meta.title)}</b><br>Runtime: Platformer<br>Goal: collect the shard and reach EXIT.`;
  beginLoop(packet,drawPlatformer,updatePlatformer);
}

function updatePlatformer(dt){
  const p=game.player, f=dt/16.7;
  p.vx=0;
  if(keys['arrowleft']||keys['a'])p.vx=-p.speed;
  if(keys['arrowright']||keys['d'])p.vx=p.speed;
  if((keys[' ']||keys['arrowup']||keys['w'])&&p.onGround){p.vy=p.jump;p.onGround=false}
  p.vy+=0.42*f;
  p.x+=p.vx*f;p.y+=p.vy*f;
  p.onGround=false;
  for(const pl of game.platforms){
    if(p.x+p.w/2>pl.x&&p.x-p.w/2<pl.x+pl.w&&p.y+p.h/2>=pl.y&&p.y+p.h/2<=pl.y+18&&p.vy>=0){
      p.y=pl.y-p.h/2;p.vy=0;p.onGround=true;
    }
  }
  if(p.y>580){p.x=170;p.y=330;p.vy=0}
  if(!game.shard.taken&&Math.abs(p.x-game.shard.x)<32&&Math.abs(p.y-game.shard.y)<45)game.shard.taken=true;
  if(game.shard.taken&&p.x>game.exit.x-30){game.over=true;game.win=true;els.proto.innerHTML='<b>Platformer clear.</b><br>Shard collected and EXIT reached. Press R to retry.'}
  game.cameraX=clamp(p.x-360,0,game.worldWidth-960);
}

function drawPlatformer(ctx,packet){
  ctx.clearRect(0,0,960,540);
  const grad=ctx.createLinearGradient(0,0,0,540);grad.addColorStop(0,'#1c2042');grad.addColorStop(1,'#693b61');ctx.fillStyle=grad;ctx.fillRect(0,0,960,540);
  ctx.save();ctx.translate(-game.cameraX,0);
  for(let i=0;i<20;i++){ctx.fillStyle=i%2?'#203857':'#162b46';ctx.fillRect(i*150,110+(i%4)*25,95,310)}
  game.platforms.forEach(pl=>{ctx.fillStyle='#45515c';ctx.fillRect(pl.x,pl.y,pl.w,pl.h);ctx.fillStyle='#79858d';ctx.fillRect(pl.x,pl.y,pl.w,10)});
  if(!game.shard.taken){ctx.fillStyle='#42c7ff';ctx.beginPath();ctx.moveTo(game.shard.x,game.shard.y-18);ctx.lineTo(game.shard.x+13,game.shard.y);ctx.lineTo(game.shard.x,game.shard.y+18);ctx.lineTo(game.shard.x-13,game.shard.y);ctx.closePath();ctx.fill()}
  ctx.fillStyle='#fff6b8';ctx.fillRect(game.exit.x,game.exit.y,game.exit.w,game.exit.h);ctx.fillStyle='#242943';ctx.font='bold 16px Arial';ctx.fillText('EXIT',game.exit.x+7,game.exit.y+38);
  ctx.fillStyle='#f4c44f';ctx.fillRect(game.player.x-14,game.player.y-27,28,54);ctx.fillStyle='#1f2433';ctx.beginPath();ctx.arc(game.player.x,game.player.y-38,13,0,Math.PI*2);ctx.fill();
  ctx.restore();
  ctx.fillStyle='#fff';ctx.font='bold 16px Arial';ctx.fillText(`Shard: ${game.shard.taken?'YES':'NO'} · Scroll ${Math.round(game.cameraX)}px`,18,26);
}

function startRunner(packet){
  game={
    mode:'runner',over:false,win:false,lastTs:performance.now(),elapsedMs:0,cameraX:0,worldWidth:3200,speed:2.1,targetSpeed:4.4,
    player:{x:220,y:360,lane:1,vy:0,jumping:false},lanes:[330,370,410],
    hazards:[{x:820,lane:1},{x:1320,lane:0},{x:1850,lane:2},{x:2380,lane:1}],
    rings:[{x:680,lane:0,taken:false},{x:1540,lane:2,taken:false},{x:2240,lane:1,taken:false}],finishX:3000
  };
  els.proto.innerHTML=`<b>${esc(packet.meta.title)}</b><br>Runtime: Runner<br>Goal: survive 15s+, collect rings, reach finish.`;
  beginLoop(packet,drawRunner,updateRunner);
}

function updateRunner(dt){
  const f=dt/16.7;
  game.elapsedMs+=dt;game.speed=Math.min(game.targetSpeed,game.speed+.0008*dt);
  if((keys['arrowup']||keys['w'])&&game.player.lane>0){game.player.lane--;keys['arrowup']=keys['w']=false}
  if((keys['arrowdown']||keys['s'])&&game.player.lane<2){game.player.lane++;keys['arrowdown']=keys['s']=false}
  if((keys[' ']||keys['arrowright'])&&!game.player.jumping){game.player.vy=-7;game.player.jumping=true}
  game.player.vy+=.36*f;game.player.y+=game.player.vy*f;
  const ground=game.lanes[game.player.lane];if(game.player.y>=ground){game.player.y=ground;game.player.vy=0;game.player.jumping=false}
  game.cameraX+=game.speed*f;
  for(const r of game.rings)if(!r.taken&&Math.abs((r.x-game.cameraX)-game.player.x)<35&&r.lane===game.player.lane)r.taken=true;
  for(const h of game.hazards)if(Math.abs((h.x-game.cameraX)-game.player.x)<30&&h.lane===game.player.lane&&!game.player.jumping){game.speed=Math.max(1.7,game.speed-1.2);h.x=-9999}
  if(game.cameraX+game.player.x>=game.finishX){game.over=true;game.win=true;els.proto.innerHTML=`<b>Runner clear.</b><br>${(game.elapsedMs/1000).toFixed(1)}s · Rings ${game.rings.filter(r=>r.taken).length}/3. Press R to retry.`}
}

function drawRunner(ctx,packet){
  ctx.clearRect(0,0,960,540);const g=ctx.createLinearGradient(0,0,0,540);g.addColorStop(0,'#f3a76b');g.addColorStop(.45,'#96c9d5');g.addColorStop(1,'#35546b');ctx.fillStyle=g;ctx.fillRect(0,0,960,540);
  ctx.save();ctx.translate(-game.cameraX,0);
  ctx.fillStyle='#293a44';ctx.fillRect(0,300,3200,180);
  game.lanes.forEach(y=>{ctx.strokeStyle='#d7d7c6';ctx.setLineDash([20,18]);ctx.beginPath();ctx.moveTo(0,y+20);ctx.lineTo(3200,y+20);ctx.stroke();ctx.setLineDash([])});
  game.hazards.forEach(h=>{if(h.x<0)return;ctx.fillStyle='#e67132';ctx.fillRect(h.x-18,game.lanes[h.lane]-16,36,32)});
  game.rings.forEach(r=>{if(r.taken)return;ctx.strokeStyle='#ffd34f';ctx.lineWidth=5;ctx.beginPath();ctx.arc(r.x,game.lanes[r.lane]-20,18,0,Math.PI*2);ctx.stroke()});
  ctx.fillStyle='#e7f4f6';ctx.fillRect(game.finishX,260,12,220);ctx.font='bold 18px Arial';ctx.fillStyle='#fff';ctx.fillText('FINISH',game.finishX-28,250);
  ctx.restore();
  ctx.fillStyle='#1b5672';ctx.fillRect(game.player.x-18,game.player.y-28,36,28);ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(game.player.x,game.player.y-38,11,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fff';ctx.font='bold 16px Arial';ctx.fillText(`Speed ${game.speed.toFixed(1)} · Rings ${game.rings.filter(r=>r.taken).length}/3 · ${(game.elapsedMs/1000).toFixed(1)}s`,18,26);
}

function startDodge(packet){
  game={
    mode:'dodge',over:false,win:false,lastTs:performance.now(),elapsedMs:0,targetMs:15000,spawnMs:0,
    player:{x:480,y:285,hp:10,speed:2.4,invuln:0},orbs:[],pickups:[{x:390,y:270,taken:false},{x:540,y:310,taken:false},{x:470,y:390,taken:false}]
  };
  els.proto.innerHTML=`<b>${esc(packet.meta.title)}</b><br>Runtime: Dodge<br>Goal: survive 15 seconds.`;
  beginLoop(packet,drawDodge,updateDodge);
}

function updateDodge(dt){
  game.elapsedMs+=dt;game.spawnMs-=dt;const p=game.player,f=dt/16.7;if(p.invuln>0)p.invuln-=dt;
  if(keys['arrowleft']||keys['a'])p.x-=p.speed*f;if(keys['arrowright']||keys['d'])p.x+=p.speed*f;if(keys['arrowup']||keys['w'])p.y-=p.speed*f;if(keys['arrowdown']||keys['s'])p.y+=p.speed*f;
  p.x=clamp(p.x,110,850);p.y=clamp(p.y,115,445);
  if(game.spawnMs<=0){game.spawnMs=Math.max(300,900-game.elapsedMs*.025);const fromTop=Math.random()<.5;game.orbs.push({x:fromTop?120+Math.random()*720:880,y:fromTop?90:110+Math.random()*330,vx:fromTop?0:-1.2-Math.random()*.8,vy:fromTop?1.1+Math.random()*.8:0})}
  game.orbs.forEach(o=>{o.x+=o.vx*f;o.y+=o.vy*f;if(Math.hypot(o.x-p.x,o.y-p.y)<24&&p.invuln<=0){p.hp=Math.max(0,p.hp-.75);p.invuln=500;o.x=-100}});
  game.orbs=game.orbs.filter(o=>o.x>-50&&o.x<1010&&o.y<590);
  game.pickups.forEach(pk=>{if(!pk.taken&&Math.hypot(pk.x-p.x,pk.y-p.y)<28){pk.taken=true;p.hp=Math.min(10,p.hp+2)}});
  if(p.hp<=0){game.over=true;game.win=false;els.proto.innerHTML='<b>Dodge failed.</b><br>Health depleted. Press R to retry.'}
  if(game.elapsedMs>=game.targetMs&&p.hp>0){game.over=true;game.win=true;els.proto.innerHTML=`<b>Dodge clear.</b><br>Survived ${(game.elapsedMs/1000).toFixed(1)}s with ${p.hp.toFixed(1)} HP. Press R to retry.`}
}

function drawDodge(ctx,packet){
  ctx.clearRect(0,0,960,540);ctx.fillStyle='#161331';ctx.fillRect(0,0,960,540);ctx.fillStyle='#25204b';ctx.fillRect(90,90,780,380);
  ctx.strokeStyle='#4b3c86';ctx.lineWidth=2;for(let x=110;x<860;x+=50){ctx.beginPath();ctx.moveTo(x,100);ctx.lineTo(x,460);ctx.stroke()}for(let y=110;y<460;y+=50){ctx.beginPath();ctx.moveTo(100,y);ctx.lineTo(860,y);ctx.stroke()}
  [[120,120],[840,120],[120,440],[840,440]].forEach(([x,y])=>{ctx.fillStyle='#2c2b35';ctx.fillRect(x-28,y-28,56,56);ctx.fillStyle='#8c4bff';ctx.beginPath();ctx.arc(x,y,14,0,Math.PI*2);ctx.fill()});
  ctx.strokeStyle='#4ff1a1';ctx.lineWidth=4;ctx.beginPath();ctx.arc(230,300,55,0,Math.PI*2);ctx.stroke();
  game.pickups.forEach(pk=>{if(pk.taken)return;ctx.fillStyle='#48e57d';ctx.beginPath();ctx.arc(pk.x,pk.y,11,0,Math.PI*2);ctx.fill()});
  game.orbs.forEach(o=>{ctx.fillStyle='#e84058';ctx.beginPath();ctx.arc(o.x,o.y,12,0,Math.PI*2);ctx.fill()});
  ctx.fillStyle='#a75be8';ctx.fillRect(game.player.x-15,game.player.y-20,30,40);ctx.fillStyle='#f0c847';ctx.beginPath();ctx.arc(game.player.x,game.player.y-27,10,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fff';ctx.font='bold 16px Arial';ctx.fillText(`HP ${game.player.hp.toFixed(1)} · ${(game.elapsedMs/1000).toFixed(1)} / 15.0s · Pickups ${game.pickups.filter(p=>p.taken).length}/3`,18,26);
}

function updateGame(dt=16.7) {
  if(!game||game.over)return;
  game.tick++; game.elapsedMs+=dt; const p=game.player; if(game.invulnMs>0)game.invulnMs-=dt; if(!game.over){p.hp=Math.max(0,p.hp-game.healthDrainPerSecond*(dt/1000));}
  if(keys['arrowleft']||keys['a']){p.x-=p.speed;p.facing=-1} if(keys['arrowright']||keys['d']){p.x+=p.speed;p.facing=1}
  if(keys['arrowup']||keys['w'])p.y-=p.speed*.7; if(keys['arrowdown']||keys['s'])p.y+=p.speed*.7;
  p.x=clamp(p.x,42,game.worldWidth-42); p.y=clamp(p.y,305,405);
  const screenX=p.x-game.cameraX, deadLeft=340, deadRight=620;
  if(screenX>deadRight)game.cameraX=clamp(p.x-deadRight,0,game.worldWidth-960);
  else if(screenX<deadLeft)game.cameraX=clamp(p.x-deadLeft,0,game.worldWidth-960);
  game.metrics.maxScroll=Math.max(game.metrics.maxScroll,game.cameraX);
  if(game.cameraX>20&&game.metrics.firstScrollMs===null)game.metrics.firstScrollMs=game.elapsedMs;
  if(!game.healthPickupTaken && Math.abs(p.x-1529)<32 && Math.abs(p.y-367)<50){
    game.healthPickupTaken=true;p.hp=Math.min(10,p.hp+2.2);
  }
  if(p.attackCooldown>0)p.attackCooldown--; if(p.attackTimer>0)p.attackTimer--;
  if(keys[' ']&&p.attackCooldown<=0){
    p.attackCooldown=28;p.attackTimer=10;game.flash=7;game.metrics.attacks++;
    game.enemies.forEach(e=>{if(!e.alive)return;const dx=e.x-p.x,dy=Math.abs(e.y-p.y),face=p.facing>0?dx>0:dx<0;if(Math.abs(dx)<78&&dy<48&&face){
      e.hp--; e.hurt=14; e.x+=p.facing*28; game.metrics.hits++;
      if(e.hp<=0){
        e.alive=false; game.metrics.enemiesDefeated++;
        if(game.metrics.firstKillMs===null) game.metrics.firstKillMs=game.elapsedMs;
      }
    }});
  }
  game.enemies.forEach(e=>{
    if(!e.alive)return;
    if(e.hurt>0){e.hurt--;return}
    if(e.attackCd>0)e.attackCd-=dt;
    const dx=p.x-e.x,dy=p.y-e.y;
    if(Math.abs(dx)>48)e.x+=Math.sign(dx)*e.speed*(dt/16.7);
    if(Math.abs(dy)>10)e.y+=Math.sign(dy)*e.speed*.42*(dt/16.7);
    if(Math.abs(dx)<38&&Math.abs(dy)<42&&e.attackCd<=0&&game.invulnMs<=0){
      const dmg=e.damage||.35;
      p.hp=Math.max(0,p.hp-dmg);
      game.metrics.damageTaken+=dmg;
      game.invulnMs=430;
      e.attackCd=700;
      p.x+=Math.sign(dx)*-20;
    }
  });
  if(game.flash>0)game.flash--;
  // lightweight difficulty governor for stress testing
  if(game.elapsedMs<8000 && p.hp<4){
    game.enemies.forEach(e=>{if(e.alive)e.speed=Math.max(.28,e.speed*.985)});
  }
  if(game.elapsedMs>12000 && game.enemies.some(e=>e.alive)){
    game.enemies.forEach(e=>{if(e.alive)e.hp=Math.min(e.hp,Math.max(1,e.maxHp-1))});
  }
  if(p.hp<=0){game.over=true;game.win=false;finishRun('Player defeated.');}
  if(!game.reinforcementTriggered && game.elapsedMs>=4500){
    game.reinforcementTriggered=true; game.wave=2; game.metrics.wavesCompleted++;
    const base=Math.max(1150,game.cameraX+980);
    game.enemies.push(
      {id:'wave2_bandana',label:'Bandana Rival',weapon:'fists',x:base,y:350,w:34,h:58,hp:4,maxHp:4,alive:true,hurt:0,speed:.46,damage:.38,role:'balanced',attackCd:0}
    );
  }
  if(!game.zone2Triggered && game.cameraX>=520){
    game.zone2Triggered=true; game.wave=3; game.metrics.wavesCompleted++;
    const base=game.cameraX+1040;
    game.enemies.push(
      {id:'zone2_knife',label:'Knife Punk II',weapon:'knife',x:base,y:380,w:34,h:58,hp:3,maxHp:3,alive:true,hurt:0,speed:.60,damage:.32,role:'knife',attackCd:0},
      {id:'zone2_rival',label:'Dock Rival',weapon:'fists',x:base+260,y:350,w:34,h:58,hp:4,maxHp:4,alive:true,hurt:0,speed:.44,damage:.38,role:'balanced',attackCd:0}
    );
  }
  if(!game.bossTriggered && game.elapsedMs>=10000){
    game.bossTriggered=true; game.wave=4; game.metrics.wavesCompleted++;
    const base=Math.max(2050,game.cameraX+1040);
    game.enemies.push(
      {id:'dock_bruiser_final',label:'Dock Bruiser',weapon:'fists',x:base,y:370,w:40,h:64,hp:7,maxHp:7,alive:true,hurt:0,speed:.31,damage:.58,role:'bruiser',attackCd:0}
    );
  }
  if(game.elapsedMs>=game.targetDurationMs && game.enemies.every(e=>!e.alive)){
    game.over=true;game.win=true;finishRun('Stage clear.');
  }
}


function finishRun(label){
  const m=game.metrics;
  const sec=(game.elapsedMs/1000).toFixed(1);
  const warnings=[];
  if(game.elapsedMs<12000)warnings.push('Encounter under 12 seconds');
  if(m.maxScroll<300)warnings.push('Camera barely scrolled');
  if(m.damageTaken>7)warnings.push('Player lost too much health');
  if(m.firstKillMs!==null&&m.firstKillMs<2500)warnings.push('First kill happened too quickly');
  if(m.attacks>0&&m.hits/m.attacks<.2)warnings.push('Low hit efficiency / attack feel may be too loose');
  els.proto.innerHTML=`<b>${label}</b><br>
    Time: ${sec}s<br>
    Enemies defeated: ${m.enemiesDefeated}<br>
    Damage taken: ${m.damageTaken.toFixed(1)}<br>
    Max scroll: ${Math.round(m.maxScroll)}px<br>
    Waves triggered: ${game.wave}<br>
    Attacks / hits: ${m.attacks} / ${m.hits}<br>
    ${warnings.length?'<span style="color:#b17a13">Warnings: '+warnings.join(' · ')+'</span>':'Thresholds look healthy.'}<br>
    Press R to retry.`;
}

function drawGame(ctx,packet) {
  const sg=packet.canonicalSceneGraph,w=960,h=540;
  ctx.clearRect(0,0,w,h);
  ctx.save();
  ctx.translate(-game.cameraX,0);
  const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,'#071126');g.addColorStop(.45,'#16244e');g.addColorStop(1,'#2f2530');ctx.fillStyle=g;ctx.fillRect(game.cameraX,0,w,h);
  ctx.fillStyle='#dedfff';ctx.beginPath();ctx.arc(620,86,20,0,Math.PI*2);ctx.fill();
  skyline(ctx);
  // building
  ctx.fillStyle='#53331f';ctx.fillRect(0,120,160,210);ctx.fillStyle='#21405a';ctx.fillRect(22,160,40,38);ctx.fillStyle='#a8d8dd';ctx.font='bold 22px Arial';ctx.fillText('B7',28,187);
  ctx.fillStyle='#321f18';ctx.fillRect(18,220,72,88);ctx.fillStyle='#c6b69d';ctx.font='bold 11px Arial';ctx.fillText('SECURITY',28,251);ctx.fillText('LEVEL 3',28,267);
  // fence
  ctx.strokeStyle='#75818a';ctx.lineWidth=2;ctx.strokeRect(176,190,300,112);for(let x=176;x<476;x+=16){ctx.beginPath();ctx.moveTo(x,190);ctx.lineTo(x+16,302);ctx.stroke();ctx.beginPath();ctx.moveTo(x+16,190);ctx.lineTo(x,302);ctx.stroke()}
  ctx.fillStyle='#6c6045';ctx.fillRect(244,208,94,44);ctx.fillStyle='#24242c';ctx.font='bold 13px Arial';ctx.fillText('CAUTION',252,226);ctx.fillText('KEEP OUT',250,243);
  barrel(ctx,190,280,'#5b7f3b');barrel(ctx,228,280,'#5b7f3b');
  // container
  ctx.fillStyle='#713a24';ctx.fillRect(510,170,255,136);ctx.fillStyle='#9b5130';for(let x=530;x<760;x+=28)ctx.fillRect(x,170,4,136);ctx.fillStyle='#bd8847';ctx.font='bold 30px Arial';ctx.fillText('ZENITH',545,235);ctx.font='bold 20px Arial';ctx.fillText('INDUSTRIES',526,264);
  ctx.fillStyle='#d7c23c';ctx.fillRect(678,207,46,46);ctx.fillStyle='#28220f';ctx.font='bold 12px Arial';ctx.fillText('DANGER',674,267);
  // ladder
  ctx.strokeStyle='#aaa';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(780,166);ctx.lineTo(780,306);ctx.moveTo(800,166);ctx.lineTo(800,306);for(let y=176;y<304;y+=16){ctx.moveTo(780,y);ctx.lineTo(800,y)}ctx.stroke();
  // floor
  ctx.fillStyle='#47414a';ctx.fillRect(0,310,game.worldWidth,h-310);for(let x=0;x<game.worldWidth;x+=56){ctx.strokeStyle='#5b5560';ctx.beginPath();ctx.moveTo(x,370);ctx.lineTo(x+56,362);ctx.stroke()}
  for(let x=0;x<game.worldWidth;x+=28){ctx.fillStyle=x%56===0?'#d0a52c':'#202124';ctx.beginPath();ctx.moveTo(x,514);ctx.lineTo(x+20,514);ctx.lineTo(x+28,540);ctx.lineTo(x+8,540);ctx.closePath();ctx.fill()}
  barrel(ctx,890,346,'#74381f');
  // extended dockyard section for scrolling test
  ctx.fillStyle='#633522';ctx.fillRect(1080,175,280,132);ctx.fillStyle='#9b5130';for(let x=1102;x<1350;x+=30)ctx.fillRect(x,175,4,132);
  ctx.fillStyle='#b98349';ctx.font='bold 28px Arial';ctx.fillText('ZENITH',1130,238);
  ctx.strokeStyle='#76818a';ctx.lineWidth=2;ctx.strokeRect(1395,190,310,112);
  for(let x=1395;x<1705;x+=16){ctx.beginPath();ctx.moveTo(x,190);ctx.lineTo(x+16,302);ctx.stroke();ctx.beginPath();ctx.moveTo(x+16,190);ctx.lineTo(x,302);ctx.stroke()}
  barrel(ctx,1460,280,'#5b7f3b');barrel(ctx,1500,280,'#5b7f3b');barrel(ctx,1840,345,'#74381f');
  // health pickup marker
  if(!game.healthPickupTaken){ctx.fillStyle='#2cc86b';ctx.fillRect(1518,356,22,22);ctx.fillStyle='#fff';ctx.font='bold 18px Arial';ctx.fillText('+',1524,374);}
  ctx.fillStyle='#53331f';ctx.fillRect(1780,120,270,210);ctx.fillStyle='#d7c23c';ctx.fillRect(1870,210,54,46);ctx.fillStyle='#28220f';ctx.font='bold 12px Arial';ctx.fillText('DANGER',1868,270);
  drawPlayer(ctx,game.player);game.enemies.forEach((e,i)=>drawEnemy(ctx,e,i));
  ctx.restore();
  hud(ctx,packet);
  if(game.flash>0){ctx.fillStyle=`rgba(255,236,170,${game.flash*.04})`;ctx.fillRect(0,0,w,h)}
  if(game.over){ctx.fillStyle='rgba(0,0,0,.58)';ctx.fillRect(0,0,w,h);ctx.fillStyle='#fff';ctx.textAlign='center';ctx.font='bold 42px Arial';ctx.fillText(game.win?'STAGE CLEAR':'YOU LOSE',480,280);ctx.font='bold 18px Arial';ctx.fillText('Press R to retry',480,318);ctx.textAlign='left'}
}

function drawPlayer(ctx,p) {
  shadow(ctx,p.x,p.y+34);ctx.fillStyle='#ece9df';ctx.fillRect(p.x-14,p.y-4,12,36);ctx.fillRect(p.x+2,p.y-4,12,36);ctx.fillStyle='#f7f5f1';ctx.fillRect(p.x-18,p.y-34,36,38);ctx.fillStyle='#161616';ctx.fillRect(p.x-20,p.y-2,40,4);
  ctx.fillStyle='#8a5936';if(p.attackTimer>0){ctx.fillRect(p.x+(p.facing>0?10:-38),p.y-28,30,8);const sx=p.x+(p.facing>0?44:-44),sy=p.y-24;ctx.strokeStyle='#ffd04f';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(sx-8,sy);ctx.lineTo(sx+8,sy);ctx.moveTo(sx,sy-8);ctx.lineTo(sx,sy+8);ctx.stroke()}else{ctx.fillRect(p.x-24,p.y-28,14,8);ctx.fillRect(p.x+10,p.y-28,14,8)}
  ctx.fillStyle='#8f603b';ctx.beginPath();ctx.arc(p.x,p.y-46,14,0,Math.PI*2);ctx.fill();ctx.fillStyle='#171717';ctx.beginPath();ctx.arc(p.x,p.y-53,18,0,Math.PI*2);ctx.fill();
}

function drawEnemy(ctx,e,i) {
  if(!e.alive)return;shadow(ctx,e.x,e.y+32);ctx.fillStyle=e.hurt>0?'#ffd087':['#6b4051','#3c5f8e','#486c48'][i%3];ctx.fillRect(e.x-16,e.y-30,32,34);ctx.fillStyle=['#78344c','#315489','#47663d'][i%3];ctx.fillRect(e.x-12,e.y-16,24,20);ctx.fillStyle='#71834b';ctx.fillRect(e.x-14,e.y+4,12,30);ctx.fillRect(e.x+2,e.y+4,12,30);ctx.fillStyle='#c88758';ctx.beginPath();ctx.arc(e.x,e.y-40,13,0,Math.PI*2);ctx.fill();ctx.fillStyle=i===0?'#cf3151':'#2452b9';ctx.fillRect(e.x-14,e.y-52,28,6);
  if(e.weapon==='knife'){ctx.fillStyle='#d4d4d5';ctx.fillRect(e.x+16,e.y-20,13,3)}
  for(let hp=0;hp<e.hp;hp++){ctx.fillStyle='#f2bd39';ctx.fillRect(e.x-14+hp*10,e.y-66,8,4)}
}

function hud(ctx,packet) {
  ctx.fillStyle='#020305';ctx.fillRect(0,0,960,66);ctx.fillRect(0,508,960,32);ctx.fillStyle='#f1cc38';ctx.font='bold 18px Arial';ctx.fillText((packet.canonicalSceneGraph.entities.find(x=>x.type==='player')?.name||'PLAYER').toUpperCase(),74,24);ctx.fillStyle='#fff';ctx.fillText('0124500',170,24);ctx.fillText('×3',304,24);ctx.fillStyle='#f59a23';ctx.font='bold 44px Arial';ctx.fillText(String(Math.max(0,15-Math.floor(game.elapsedMs/1000))).padStart(2,'0'),466,46);ctx.fillStyle='#92b7ff';ctx.font='bold 20px Arial';ctx.fillText('PRESS START',730,24);
  ctx.fillStyle='#314462';ctx.fillRect(14,12,42,42);ctx.fillStyle='#d6c04a';ctx.fillRect(76,32,126,10);ctx.fillStyle='#2da8e2';ctx.fillRect(76,32,126*(game.player.hp/10),10);ctx.strokeStyle='#fff';ctx.strokeRect(76,32,126,10);
  ctx.fillStyle='#d5d9e2';ctx.font='bold 17px Arial';ctx.fillText('STAGE 3-1',360,530);ctx.font='bold 12px Arial';ctx.fillText('15s STRESS RUN',490,530);ctx.fillText('SCROLL '+Math.round(game.cameraX)+'px',655,530);
  game.enemies.slice(0,2).forEach((e,i)=>{const x=i?700:126,label=i?'BANDANA':'KNIFE';ctx.fillStyle='#fff';ctx.fillText(label,x-22,529);ctx.fillStyle='#c22828';ctx.fillRect(x+52,517,108,8);ctx.fillStyle='#f2bf38';ctx.fillRect(x+52,517,108*Math.max(0,e.hp)/3,8)})
}

function skyline(ctx) {ctx.fillStyle='#1f274e';[80,130,110,160,100,180,150,95,200,120,165,145,92].forEach((ht,i)=>ctx.fillRect(200+i*46,220-ht,28,ht));ctx.strokeStyle='#294667';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(795,118);ctx.lineTo(845,58);ctx.lineTo(898,118);ctx.stroke()}
function barrel(ctx,x,y,color) {ctx.fillStyle=color;ctx.fillRect(x,y,34,52);ctx.strokeStyle='#292529';ctx.lineWidth=2;ctx.strokeRect(x,y,34,52);ctx.beginPath();ctx.moveTo(x,y+12);ctx.lineTo(x+34,y+12);ctx.moveTo(x,y+36);ctx.lineTo(x+34,y+36);ctx.stroke()}
function shadow(ctx,x,y) {ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(x,y,20,7,0,0,Math.PI*2);ctx.fill()}
function inferTitle(t) {return /alex/i.test(t)&&/dockyard|shipping|container/i.test(t)?'Urban Shipping Clash':'XPLAY Prototype Draft'}
function normalizeGenre(g) {g=g.toLowerCase().replace(/\s+/g,'');if(g==='openworld')return'openworld';if(g==='collectible')return'collect';return g}
function dedupeGenreScores(arr) {const m=new Map();arr.forEach(x=>{if(!m.has(x.type)||m.get(x.type).score<x.score)m.set(x.type,x)});return[...m.values()]}
function slug(s) {return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}
function clean(s) {return String(s||'').replace(/^[\s:;,-]+|[\s:;,-]+$/g,'').replace(/\s+/g,' ')}
function clamp(v,a,b) {return Math.max(a,Math.min(b,v))}
function esc(v) {return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')}
function setStatus(s) {els.status.textContent=s}

currentPacket=interpret();render(currentPacket);setStatus('Sample loaded. V2 is ready.');
