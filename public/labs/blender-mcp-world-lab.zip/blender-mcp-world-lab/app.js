import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

// Application State
let scene, camera, renderer, clock;
let controls;
let groundMesh = null;
let obstacles = [];
let landmarks = [];
let playerStart = { x: 0, y: -38, z: 1.7 };
let playerVelocity = new THREE.Vector3();
let isGrounded = false;
let manifest = null;

const playerHeight = 1.7;
const playerRadius = 0.8;
const gravity = 25.0;
const walkSpeed = 6.0;
const sprintSpeed = 12.0;

const keysPressed = {
  w: false,
  a: false,
  s: false,
  d: false,
  shift: false
};

// Debug helpers
let debugHelpersGroup;
let collisionDebugMode = false;

// UI Elements
const statX = document.getElementById('stat-x');
const statY = document.getElementById('stat-y');
const statZ = document.getElementById('stat-z');
const statHeading = document.getElementById('stat-heading');
const statNearest = document.getElementById('stat-nearest');
const statDist = document.getElementById('stat-dist');
const btnReset = document.getElementById('btn-reset');
const btnDebug = document.getElementById('btn-debug');
const instructions = document.getElementById('instructions');

// Coordinate mapping: Blender (Z=up, Y=forward) <-> Three.js (Y=up, Z=backward)
function blenderToThree(pos) {
  return new THREE.Vector3(pos.x, pos.z, -pos.y);
}

function threeToBlender(pos) {
  return new THREE.Vector3(pos.x, -pos.z, pos.y);
}

// Initialize the 3D scene
async function init() {
  // Create Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a141e);
  scene.fog = new THREE.FogExp2(0x0a141e, 0.015);

  // Create Camera
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

  // Setup Renderer
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  document.getElementById('canvas-container').appendChild(renderer.domElement);

  clock = new THREE.Clock();

  // Controls Setup
  controls = new PointerLockControls(camera, document.body);
  scene.add(controls.getObject());

  // Input Setup
  setupInput();

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  const dirLight = new THREE.DirectionalLight(0xffffff, 1.0);
  dirLight.position.set(20, 40, 20);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.width = 2048;
  dirLight.shadow.mapSize.height = 2048;
  dirLight.shadow.camera.near = 0.5;
  dirLight.shadow.camera.far = 150;
  const d = 60;
  dirLight.shadow.camera.left = -d;
  dirLight.shadow.camera.right = d;
  dirLight.shadow.camera.top = d;
  dirLight.shadow.camera.bottom = -d;
  scene.add(dirLight);

  // Add grid floor visual helper at y = 0
  const gridHelper = new THREE.GridHelper(120, 12, 0x00d2ff, 0x003344);
  gridHelper.position.y = -0.05;
  scene.add(gridHelper);

  // Debug Group for Colliders
  debugHelpersGroup = new THREE.Group();
  debugHelpersGroup.visible = false;
  scene.add(debugHelpersGroup);

  // Load Manifest & GLB
  try {
    await loadManifest();
    await loadGLB();
  } catch (error) {
    console.error("Error loading scene assets:", error);
  }

  // Set initial player transform
  resetPlayer();

  // Resize Listener
  window.addEventListener('resize', onWindowResize);

  // Start Update Loop
  animate();
}

// Input Setup
function setupInput() {
  document.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();
    if (key === 'w' || key === 'arrowup') keysPressed.w = true;
    if (key === 'a' || key === 'arrowleft') keysPressed.a = true;
    if (key === 's' || key === 'arrowdown') keysPressed.s = true;
    if (key === 'd' || key === 'arrowright') keysPressed.d = true;
    if (e.key === 'Shift') keysPressed.shift = true;
  });

  document.addEventListener('keyup', (e) => {
    const key = e.key.toLowerCase();
    if (key === 'w' || key === 'arrowup') keysPressed.w = false;
    if (key === 'a' || key === 'arrowleft') keysPressed.a = false;
    if (key === 's' || key === 'arrowdown') keysPressed.s = false;
    if (key === 'd' || key === 'arrowright') keysPressed.d = false;
    if (e.key === 'Shift') keysPressed.shift = false;
  });

  btnReset.addEventListener('click', (e) => {
    e.stopPropagation();
    resetPlayer();
  });

  btnDebug.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleCollisionDebug();
  });
}

// Load manifest
async function loadManifest() {
  const response = await fetch('assets/XPLAY_world_test_manifest.json');
  manifest = await response.json();
  console.log("Manifest loaded:", manifest);

  if (manifest.playerStart) {
    playerStart = manifest.playerStart;
  }
  if (manifest.landmarks) {
    landmarks = manifest.landmarks;
  }
}

// Load GLB
function loadGLB() {
  return new Promise((resolve, reject) => {
    const loader = new GLTFLoader();
    loader.load('assets/XPLAY_world_test.glb', (gltf) => {
      const glbScene = gltf.scene;
      scene.add(glbScene);
      console.log("GLB Loaded successfully:", glbScene);

      // Traversal to find collision meshes and identify landmark coordinate overrides if any
      glbScene.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;

          // Identify roles based on names
          if (child.name === 'XPLAY_GROUND') {
            groundMesh = child;
            console.log("Ground mesh mapped:", child);
          } else if (child.name.startsWith('XPLAY_BUILDING_') || 
                     child.name === 'XPLAY_BRIDGE' || 
                     child.name === 'XPLAY_TOWER') {
            
            // Compute bounding box for collision detection
            child.geometry.computeBoundingBox();
            
            // Clone bounding box to world coordinates
            const box = child.geometry.boundingBox.clone();
            child.updateMatrixWorld(true);
            box.applyMatrix4(child.matrixWorld);
            
            child.userData.boundingBox = box;
            obstacles.push(child);

            // Create red outline outline helper
            const helper = new THREE.Box3Helper(box, new THREE.Color(0xff3333));
            debugHelpersGroup.add(helper);

            console.log(`Obstacle registered: ${child.name}`, box);
          }
        }
      });

      resolve();
    }, undefined, (err) => {
      reject(err);
    });
  });
}

// Reset player to starting position
function resetPlayer() {
  const threePos = blenderToThree(playerStart);
  controls.getObject().position.copy(threePos);
  playerVelocity.set(0, 0, 0);
  isGrounded = true;
  
  // Orient to face positive Y in Blender (which is negative Z in Three.js)
  // To do that, we reset camera rotation to look forward along -Z
  camera.rotation.set(0, 0, 0);
  console.log("Player reset to spawn:", threePos);
}

// Toggle Collision Visuals
function toggleCollisionDebug() {
  collisionDebugMode = !collisionDebugMode;
  debugHelpersGroup.visible = collisionDebugMode;
  console.log("Collision debug toggled:", collisionDebugMode);
}

// Handle Window Resize
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// Animation loop
function animate() {
  requestAnimationFrame(animate);

  const deltaTime = Math.min(clock.getDelta(), 0.1); // cap physics step to prevent spikes

  if (controls.isLocked) {
    updateMovement(deltaTime);
  }

  updateHUD();

  renderer.render(scene, camera);
}

// Process keyboard controls and collision
function updateMovement(deltaTime) {
  // Determine speed
  const speed = keysPressed.shift ? sprintSpeed : walkSpeed;

  // Build movement vectors
  const forward = new THREE.Vector3();
  camera.getWorldDirection(forward);
  forward.y = 0;
  forward.normalize();

  const right = new THREE.Vector3();
  right.crossVectors(forward, camera.up).normalize();

  const moveDirection = new THREE.Vector3();
  if (keysPressed.w) moveDirection.add(forward);
  if (keysPressed.s) moveDirection.addScaledVector(forward, -1);
  if (keysPressed.d) moveDirection.add(right);
  if (keysPressed.a) moveDirection.addScaledVector(right, -1);
  moveDirection.normalize();

  // Apply gravity
  playerVelocity.y -= gravity * deltaTime;

  // Resolve horizontal motion with wall sliding
  const currentPos = controls.getObject().position;

  // Horizontal motion along X
  if (moveDirection.x !== 0) {
    const nextX = currentPos.x + moveDirection.x * speed * deltaTime;
    if (!checkObstacleCollision(nextX, currentPos.y, currentPos.z)) {
      currentPos.x = nextX;
    }
  }

  // Horizontal motion along Z
  if (moveDirection.z !== 0) {
    const nextZ = currentPos.z + moveDirection.z * speed * deltaTime;
    if (!checkObstacleCollision(currentPos.x, currentPos.y, nextZ)) {
      currentPos.z = nextZ;
    }
  }

  // Apply vertical motion
  currentPos.y += playerVelocity.y * deltaTime;

  // Ground collision / grounding
  let groundHeight = 0;
  if (groundMesh) {
    const raycaster = new THREE.Raycaster();
    // Raycast down from above the player
    raycaster.set(new THREE.Vector3(currentPos.x, currentPos.y + 10, currentPos.z), new THREE.Vector3(0, -1, 0));
    const intersects = raycaster.intersectObject(groundMesh);
    if (intersects.length > 0) {
      groundHeight = intersects[0].point.y;
    }
  }

  const minHeight = groundHeight + playerHeight;
  if (currentPos.y <= minHeight) {
    currentPos.y = minHeight;
    playerVelocity.y = 0;
    isGrounded = true;
  } else {
    isGrounded = false;
  }
}

// Check if player position intersects with any obstacle bounding boxes
function checkObstacleCollision(x, y, z) {
  for (const obs of obstacles) {
    const box = obs.userData.boundingBox;
    if (box) {
      // Horizontal overlap check
      if (x >= box.min.x - playerRadius && x <= box.max.x + playerRadius &&
          z >= box.min.z - playerRadius && z <= box.max.z + playerRadius) {
        
        // Vertical height check: player feet must be below obstacle roof, and player head above obstacle floor
        if (y - playerHeight <= box.max.y && y >= box.min.y) {
          return true; // Collision!
        }
      }
    }
  }
  return false;
}

// Update UI Panel
function updateHUD() {
  const currentPos = controls.getObject().position;
  const blenderPos = threeToBlender(currentPos);

  // Update text
  statX.textContent = blenderPos.x.toFixed(2);
  statY.textContent = blenderPos.y.toFixed(2);
  statZ.textContent = blenderPos.z.toFixed(2);

  // Heading calculation: North is +Y in Blender (which is -Z in Three.js)
  const dir = new THREE.Vector3();
  camera.getWorldDirection(dir);
  dir.y = 0;
  dir.normalize();
  let heading = Math.atan2(dir.x, -dir.z) * (180 / Math.PI);
  if (heading < 0) heading += 360;
  statHeading.textContent = Math.round(heading);

  // Landmark distance calculations using Blender coordinates
  let nearest = null;
  let minDist = Infinity;

  landmarks.forEach((lm) => {
    const dx = blenderPos.x - lm.x;
    const dy = blenderPos.y - lm.y;
    const dz = blenderPos.z - lm.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (dist < minDist) {
      minDist = dist;
      nearest = lm;
    }
  });

  if (nearest) {
    statNearest.textContent = nearest.objectName;
    statDist.textContent = minDist.toFixed(2);
  } else {
    statNearest.textContent = "None";
    statDist.textContent = "0.00";
  }
}

// Run application
init();
